#include <avr/io.h>
#include <avr/interrupt.h>
#include "init.h"

void port_init(void)
{
    PORTB = 0x00;
    DDRB = 0xff;
    PORTC = 0x00;               //m103 output only
    DDRC = 0xff;
    PORTD = 0x01;
    DDRD = 0xfe;
}

void timer0_init(void)
{
    TCCR0 = 0x00;               //stop
//    TCNT0 = 208; //set count 16934400/8/(256-208)=44100
    TCCR0 = 0x02;               //start timer
}

//SPI initialize
// clock rate: 4233600hz
void spi_init(void)
{
    SPCR = 0x50;                //setup SPI
    SPSR = 0x01;                //setup SPI
}

//UART0 initialize
// desired baud rate: 2400
// actual: baud rate:2400 (0.0%)
void uart0_init(void)
{
    UCSRB = 0x00;               //disable while setting baud rate
    UCSRA = 0x00;
    UCSRC = _BV(URSEL) | 0x06;
    UBRRL = (F_CPU / BAUD_RATE / 16 - 1) & 0xff;
    UBRRH = (F_CPU / BAUD_RATE / 16 - 1) >> 8;
/*    UBRRH = 1;
    UBRRL = 184;// = 0x1d8;*/
    UCSRB = 0x08;
}

//call this routine to initialize all peripherals
void init_devices(void)
{

    //stop errant interrupts until set up
    cli();                      //disable all interrupts
    port_init();
    timer0_init();
    spi_init();
    uart0_init();

    MCUCR = 0x00;
    GICR = 0x00;
    TIMSK = 0x01;               //timer interrupt sources
    sei();                      //re-enable interrupts
    //all peripherals are now initialized
}
