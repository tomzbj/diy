#ifndef _SD_H
#define _SD_H

#include <stdint.h>

//uint8_t spi_writebyte( uint8_t data );
extern uint8_t sd_idle_state(void);
extern uint8_t sd_read_sector(uint32_t addr, uint8_t * p);
extern uint8_t sd_read_data(uint8_t * dest, uint32_t sector, uint16_t offset,
                            uint16_t count);

#endif
