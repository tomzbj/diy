#ifndef _UART_SPI_SD_H
#define _UART_SPI_SD_H

#include "misc.h"

void uart_puts(char *str);
void uart_write(char *buf, u16 n);
u8 sd_idle_state(void);
u8 sd_read_sector(u32 addr, u8 * p);

#endif
