#ifndef _INIT_H
#define _INIT_H

extern void init_devices(void);

#endif
