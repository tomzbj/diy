#include <avr/io.h>
#include <avr/wdt.h>
#include <avr/interrupt.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
//#include <avr/pgmspace.h>
#include <util/delay.h>
#include "init.h"
#include "uart_spi_sd.h"
#include "misc.h"

static struct {
    u16 addr_boot;
    u16 addr_fat;
    u16 addr_rootdir;
    u16 addr_cluster;
    u8 sectors_per_cluster;
    u16 num_reserved_sectors;
    u16 sectors_per_fat;
} g_sd;

volatile static u8 g_sector[512];
volatile static u8 g_buf1[32], g_buf2[32];
volatile static u8 g_currbuf = 1, g_updatebuf = 0;

struct fileinfo {
    u16 first_cluster;
    u32 filesize;
};

void abortmsg(char *msg, u8 data);

void get_sd_info(void)
{

    u8 r1;

    r1 = sd_idle_state();
    if (r1 != 0)
        abortmsg("idle failed", r1);

    memset((void *)g_sector, '\0', 512);
    r1 = sd_read_sector(0, (void *)g_sector);   //mbr address
    if (g_sector[510] != 0x55 || g_sector[511] != 0xaa)
        abortmsg("read mbr failed", 0);

    memcpy(&g_sd.addr_boot, (void *)&g_sector[454], 2); // bootg_sector address

    r1 = sd_read_sector(g_sd.addr_boot, (void *)g_sector);
    if (g_sector[510] != 0x55 || g_sector[511] != 0xaa)
        abortmsg("read boot g_sector failed", 0);

    memcpy(&g_sd.sectors_per_cluster, (void *)&g_sector[0xd], 1);
    memcpy(&g_sd.num_reserved_sectors, (void *)&g_sector[0xe], 2);
    memcpy(&g_sd.sectors_per_fat, (void *)&g_sector[0x16], 2);
    g_sd.addr_fat = g_sd.addr_boot + g_sd.num_reserved_sectors;
    g_sd.addr_rootdir =
        g_sd.addr_boot + g_sd.num_reserved_sectors + 2 * g_sd.sectors_per_fat;
    g_sd.addr_cluster = g_sd.addr_rootdir + 32 - 2 * g_sd.sectors_per_cluster;

}

int8_t get_file_info(char *fname, struct fileinfo *p)
{

    int16_t i, j;
    u8 r1, type, status, *tt;
    char *t, filename[12], *extname;

    strcpy(filename, fname);
    t = filename + strlen(filename) - 1;
    while (*t != '.' && t > filename)
        t--;
    if (t == filename)
        extname = NULL;
    else {
        *t = '\0';
        extname = t + 1;
    }

    status = 0;
    for (j = 0; j < 32; j++) {
        r1 = sd_read_sector(g_sd.addr_rootdir + j, (void *)g_sector);

        for (i = 0; i < 16; i++) {
            type = g_sector[i * 32];
            if (type == 0 || type == 0xe5 || type == '.')   // empty, deleted, currdir, parentdir
                continue;
            if (g_sector[i * 32 + 0xb] & 0x10)  // is subdir
                continue;

            tt = &g_sector[i * 32 + 8 - 1];
            while (*tt == ' ') {
                *tt = '\0';
                tt--;
            }
            tt = &g_sector[i * 32 + 11 - 1];
            while (*tt == ' ') {
                *tt = '\0';
                tt--;
            }

            if (strncasecmp(filename, (char *)(&g_sector[i * 32]), 8) == 0 && 
                    strncasecmp(extname, (char *)(&g_sector[i*32+8]), 3) == 0) {

                p->first_cluster = *(u16 *) (&g_sector[i * 32 + 0x1a]);
                p->filesize = *(u32 *) (&g_sector[i * 32 + 0x1c]);
                status = 1;
                break;
            }
            if (status == 1)
                break;
        }
    }
    return status;
}

ISR(TIMER1_OVF_vect)
{

    static u8 t = 0, n = 0;

    TCNT1H = 0xff;
    TCNT1L = 0x1;

    t++;
    if (t % 2)
        return;

    if (g_currbuf == 1)
        OCR1A = g_buf1[n % 32]; // >> 8) & 0xff) | ( (g_buf1[n&0xf] << 8) & 0xff00);
    else
        OCR1A = g_buf2[n % 32]; // >> 8) & 0xff) | ( (g_buf2[n&0xf] << 8) & 0xff00);

    n++;
    if (n % 32 == 31) {
        g_currbuf = 3 - g_currbuf;
        g_updatebuf = 1;
    }
}

void feed_data(u8 * pdata, u16 size)
{

    u8 n;
    do {
        n = 32;
        if (size < n)
            n = size;

        while (g_updatebuf == 0) ;
        if (g_currbuf == 2) {
            memcpy((void *)g_buf1, pdata, n);
        } else {
            memcpy((void *)g_buf2, pdata, n);
        }
        g_updatebuf = 0;
        size -= n;
        pdata += n;
    } while (size > 0);

}

void view_file(char *filename)
{

    struct fileinfo finfo;
    u16 n_clusters, next_cluster;
    u8 i, ret;

    ret = get_file_info(filename, &finfo);
    if (ret == 0)
        abortmsg("Open file error!", 0);

    n_clusters = finfo.filesize / (g_sd.sectors_per_cluster * 512) + 1;

    char buf[32];
    //sprintf( buf, "n_clusters:%d\r\nfirstcluster:%d\r\n", n_clusters, finfo.first_cluster );
    uart_puts(buf);
    next_cluster = finfo.first_cluster;

    do {

        // read a cluster
        for (i = 0; i < g_sd.sectors_per_cluster; i++) {
            sd_read_sector(g_sd.addr_cluster +
                           ((u32) next_cluster) *
                           g_sd.sectors_per_cluster + i, (void *)g_sector);
            if (finfo.filesize > 512) {
//                uart_write( (char *)g_sector, 512 );
                feed_data((void *)g_sector, 512);
                finfo.filesize -= 512;
            } else {
//                uart_write( (char *)g_sector, finfo.filesize );
                feed_data((void *)g_sector, finfo.filesize);
                break;
            }
        }

        // get addr of next cluster
        sd_read_sector(g_sd.addr_fat + next_cluster / (512 / 2),
                       (void *)g_sector);
        next_cluster =
            *((u16 *) (&g_sector[(next_cluster % (512 / 2)) * 2]));
        n_clusters--;

    } while (n_clusters > 0);

}

void abortmsg(char *msg, u8 data)
{

    char buf[32];
    //sprintf( buf, "%s\t%d\n", msg, data );
    uart_puts(buf);
    while (1) ;
}

u16 get_avail_mem(void)
{
    u8 *p;
    u16 i;
    for (i = 1; i < 65534; i++) {
        p = malloc(i);
        if (!p)
            break;
        free(p);
    }
    return i - 1;
}
int main(void)
{

    static char buf[32];
    struct fileinfo finfo;

    init_devices();
    _delay_ms(50);
    PORTB &= _BV(2);
    _delay_ms(50);

    get_sd_info();
    {
        u8 old_osccal, i;
        old_osccal = OSCCAL;
        for (i = old_osccal; i <= 242; i++) {
            OSCCAL = i;
            _delay_ms(5);
        }
        UBRRL = 37;
        UBRRH = 1;
    }
/*
    { abortmsg( "OSCCAL:", OSCCAL ); }
    while(1);
  */

    memset(&finfo, 0, sizeof(finfo));
    get_file_info("se_m_26.wav", &finfo);
    //sprintf( buf, "%u\t%lu\r\n", finfo.first_cluster, finfo.filesize );
    uart_puts(buf);

    uart_puts("-------------start-------------");
    sei();
    view_file("face1.wav");
//    cli();
    uart_puts("--------------end--------------");

    //sprintf( buf, "available mem:%d\r\n\r\n", get_avail_mem() );
    uart_puts(buf);

    while (1) ;

    return 0;
}
