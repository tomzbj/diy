#include <avr/io.h>
#include "lcd1602_3wire.h"
#include <util/delay.h>

#define LCD_SET_EN LCD_PORT |= _BV(LCD_EN)	
#define LCD_SET_DATA LCD_PORT |= _BV(LCD_DATA)	
#define LCD_SET_RS LCD_PORT |= _BV(LCD_RS)	
#define LCD_SET_CLK LCD_PORT |= _BV(LCD_CLK)	
#define LCD_CLR_EN LCD_PORT &= ~_BV(LCD_EN)	
#define LCD_CLR_DATA LCD_PORT &= ~_BV(LCD_DATA)	
#define LCD_CLR_RS LCD_PORT &= ~_BV(LCD_RS)	
#define LCD_CLR_CLK LCD_PORT &= ~_BV(LCD_CLK)	

#define lcd_wait() _delay_us(100)
#define lcd_en() do { LCD_SET_EN; _delay_us(25); LCD_CLR_EN; } while(0)

static void lcd_command(u8 byte);
static void lcd_data(u8 data);
static void lcd_addcirc(void);

static
void lcd_write(u8 byte) 
{
    int i;
    for(i=0; i<8; i++ ) {
        LCD_CLR_CLK;
        if( byte & 0x80 )
            LCD_SET_DATA;
        else
            LCD_CLR_DATA;
        LCD_SET_CLK;
        byte <<= 1;
        _delay_us(10);
    }
}

static
void lcd_command(u8 cmd)
{
	lcd_wait();
	lcd_write(cmd);
    LCD_CLR_RS;
    lcd_en();
}

static
void lcd_data(u8 data)
{
	lcd_wait();
	lcd_write(data);
    LCD_SET_RS;
    lcd_en();
}

void lcd_puts(char *str)
{
	int k;
	k = 0;
	lcd_command(0x80 + k);
	while (*str) {
		if (k == LCD_WIDTH)
			lcd_command(0xc0 + k - LCD_WIDTH);
		lcd_data(*str);
		str++;
		k++;
	}
}

static
void lcd_addcirc()
{
    int i;
    u8 mask[] = { 0xe, 0xa, 0xe, 0x0, 0x0, 0x0, 0x0, 0x0 };
    for( i=0; i<8; i++ ) {
        lcd_command( 0x40+8+i );
        lcd_data(mask[i]);
    }
}

void lcd_init()
{
    _delay_ms(25);
    lcd_command(0x38); _delay_ms(5);
    lcd_command(0x38); _delay_ms(5);
    lcd_command(0x38); _delay_ms(5);
    lcd_command(0x38); _delay_ms(5);
    lcd_command(0x08); _delay_ms(1);
    lcd_command(0x01); _delay_ms(1);
    lcd_command(0x06); _delay_ms(1);
    lcd_command(0x0c); _delay_ms(1);
    lcd_addcirc();
}

void lcd_clear()
{
    lcd_command(0x1);
    _delay_ms(5);
}
