#include <avr/io.h>
#include <stdint.h>

void uart_tx(uint8_t data)
{

    while (!(UCSRA & _BV(UDRE))) ;
    UDR = data;
}

void uart_puts(char *str)
{

    while (*str) {
        uart_tx(*str);
        str++;
    }
}

void uart_write(char *str, int16_t n)
{

    while (n > 0) {
        uart_tx(*str);
        str++;
        n--;
    }
}
