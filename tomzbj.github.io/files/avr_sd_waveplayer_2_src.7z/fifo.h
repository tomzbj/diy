#ifndef _FIFO_H
#define _FIFO_H

#include <stdint.h>

#define MAXSIZE 128

typedef uint16_t fifo_elem_type;

void fifo_init(void);
#define fifo_clear() fifo_init()

int fifo_is_empty(void);
int fifo_is_full(void);
int fifo_get_length(void);
int fifo_get_head(fifo_elem_type * e);
int fifo_insert(fifo_elem_type e);
int fifo_del(fifo_elem_type * e);
void fifo_traverse(void (*vi) (fifo_elem_type));

#endif
