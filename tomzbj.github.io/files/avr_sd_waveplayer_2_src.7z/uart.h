#ifndef _UART_H
#define _UART_H

extern void uart_puts(char *);
extern void uart_write(char *, int16_t);

#endif
