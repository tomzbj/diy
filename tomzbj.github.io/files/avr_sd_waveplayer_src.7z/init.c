#include <avr/io.h>
#include <avr/interrupt.h>
#include "misc.h"

void port_init(void)
{
    PORTB = 0x0;
    DDRB = 0xff;
    PORTC = 0xff;               //m103 output only
    DDRC = 0xff;
    PORTD = 0xff;
    DDRD = 0xff;
}
void timer1_init(void)
{

    TCCR1B = 0x00;              //stop
    TCNT1H = 0xFF;              //setup
    TCNT1L = 0x00;
    OCR1AH = 0x00;
    OCR1AL = 0xFF;
    OCR1BH = 0x00;
    OCR1BL = 0xFF;
    ICR1H = 0x00;
    ICR1L = 0xFF;
    TCCR1A = 0xC1;
    TCCR1B = 0x09;              //start Timer
}

//SPI initialize
// clock rate: 132300hz
void spi_init(void)
{
    DDRB &= ~(1 << 4);          // MISO as input
    SPCR = 0x53;                //setup SPI
    SPSR = 0x00;                //setup SPI
}

//UART0 initialize
// desired baud rate: 2400
// actual: baud rate:2400 (0.0%)
void uart0_init(void)
{
    UCSRB = 0x00;               //disable while setting baud rate
    UCSRA = 0x00;
    UCSRC = (1 << URSEL) | 0x06;
/*    UBRRL = 54; //set baud rate lo 19200
    UBRRH = 0x0; //set baud rate hi */
    UBRRL = 207;
    UBRRH = 0;
    UCSRB = 0x08;
}

//call this routine to initialize all peripherals
void init_devices(void)
{
    //stop errant interrupts until set up
    cli();                      //disable all interrupts
    port_init();
    timer1_init();
    spi_init();
    uart0_init();

    MCUCR = 0x00;
    GICR = 0x00;
    TIMSK = 1 << TOIE1;         //timer interrupt sources
    sei();                      //re-enable interrupts
    //all peripherals are now initialized
}
