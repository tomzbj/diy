#ifndef _LCD1602_H
#define _LCD1602_H
#include "../misc.h"

#define LCD_WIDTH 8 

#define LCD_PORT PORTA

#define LCD_EN 0
#define LCD_DATA 1
#define LCD_RS 1
#define LCD_CLK 2

extern void lcd_init(void);
extern void lcd_puts(char *s);
extern void lcd_clear(void);

#endif
