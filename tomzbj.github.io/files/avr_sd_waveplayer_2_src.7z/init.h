#ifndef _INIT_H
#define _INIT_H

#define BAUD_RATE 2400UL

extern void init_devices(void);
#endif
