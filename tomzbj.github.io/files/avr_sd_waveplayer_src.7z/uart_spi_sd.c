#include <avr/io.h>
#include <util/delay.h>
#include "misc.h"

#define SET_SPI_CS do { PORTB |= _BV(2); } while(0)
#define CLR_SPI_CS do { PORTB &= ~_BV(2); } while(0)

u8 sd_command(u8 cmd, u32 arg, u8 crc);

void uart_tx(u8 data)
{
    while (!(UCSRA & _BV(UDRE))) ;
    UDR = data;
}

void uart_puts(char *str)
{
    while (*str) {
        uart_tx(*str);
        str++;
    }
}

void uart_write(char *buf, u16 n)
{
    while (n) {
        uart_tx(*buf);
        buf++;
        n--;
    }
}

u8 spi_writebyte(u8 data)
{
    SPDR = data;
    while (!(SPSR & (1 << SPIF))) ;

    return SPDR;
}

#define spi_readbyte() spi_writebyte(0xff)

u8 sd_idle_state(void)
{
    u8 i, retry, r1;

    CLR_SPI_CS;
    _delay_ms(1);
    for (i = 0; i < 20; i++)
        spi_writebyte(0xff);

    retry = 0;
    do {
        r1 = sd_command(0, 0, 0x95);
        retry++;
    } while (r1 != 1 && retry < 100);
    if (retry >= 100)
        return 1;
    retry = 0;
    do {
        r1 = sd_command(1, 0, 0x95);
    } while (r1 && retry < 100);
    if (retry >= 100)
        return 2;

    r1 = sd_command(59, 0, 0x95);
    r1 = sd_command(16, 512, 0x95);

    _delay_ms(1);
    SPCR &= ~(0x3);
    SET_SPI_CS;

    return 0;
}

u8 sd_command(u8 cmd, u32 arg, u8 crc)
{
    u8 r1, retry = 0;
    SET_SPI_CS;
    spi_writebyte(0xff);
    spi_writebyte(0xff);
    spi_writebyte(0xff);
    CLR_SPI_CS;
    spi_writebyte(cmd | 0x40);
    spi_writebyte(0xff & (arg >> 24));
    spi_writebyte(0xff & (arg >> 16));
    spi_writebyte(0xff & (arg >> 8));
    spi_writebyte(0xff & arg);
    spi_writebyte(crc);

    do {
        r1 = spi_writebyte(0xff);
        retry++;
    } while (r1 == 0xff && retry < 100);

    return r1;
}

u8 sd_read_sector(u32 addr, u8 * p)
{ 
    u8 r1 = 0;
    u16 i;
    addr <<= 9;
    r1 = sd_command(17, addr, 0x95);    //����RESPONSE     
//    { char buf[32]; sprintf( buf, "r1=%d", r1 ); uart_puts(buf); }
    while (spi_writebyte(0xff) != 0xfe) ;   //ֱ����ȡ�������ݵĿ�ʼͷ0XFE,�ż���
    for (i = 0; i < 512; i++) {
        *p = spi_readbyte();
        p++;
    }
    spi_readbyte();
    spi_readbyte();
    SET_SPI_CS;
    return (r1);
}
