#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <util/delay.h>
#include "misc.h"
#include "libs/lcd1602_3wire.h"

#define SET_BK PORTA |= _BV(3)
#define CLR_BK PORTA &= ~_BV(3)

static u32 time = 23 * 3600L + 19 * 60 + 48;

volatile enum { NORMAL, HR_ADJ, MIN_ADJ, SEC_ADJ } g_status = NORMAL;

void update_disp(void)
{
    static u8 k = 0;
    char buf[9] = "12:34:56";

    u8 ss = time % 60;
    u8 mm = (time / 60) % 60;
    u8 hh = time / 3600;


    buf[0] = '0' + hh / 10;
    buf[1] = '0' + hh % 10;
    if( g_status == HR_ADJ && k%2 == 0 )
        buf[0] = buf[1] = ' ';
    buf[3] = '0' + mm / 10;
    buf[4] = '0' + mm % 10;
    if( g_status == MIN_ADJ && k%2 == 0 )
        buf[3] = buf[4] = ' ';
    buf[6] = '0' + ss / 10;
    buf[7] = '0' + ss % 10;
    if( g_status == SEC_ADJ && k%2 == 0 )
        buf[6] = buf[7] = ' ';
    lcd_clear();
    lcd_puts(buf);

    if( (hh==23 || hh==0) && k%2 == 0)
        PORTA |= _BV(3);
    else
        PORTA &= ~_BV(3);

    k++;
    if(k%2==0)
        time++;
    time %= 86400;
}

void read_key(void)
{
    static u32 key1 = 0, key2 = 0;

    key1 <<= 1;
    key2 <<= 1;

    if( ! (PINA & _BV(4) ))
        key1 |= 0x1;
    if( ! (PINA & _BV(6) ))
        key2 |= 0x1;

    if( key1 == 0xfffffffc ) {
        switch( g_status ) {
            case NORMAL: g_status = HR_ADJ; break;
            case HR_ADJ: g_status = MIN_ADJ; break;
            case MIN_ADJ: g_status = SEC_ADJ; break;
            case SEC_ADJ: g_status = NORMAL; break;
        }
    }
    else if ( (key1 & 0xff) == 0xfc ) {
        switch( g_status ) {
            case HR_ADJ: 
                time += 3600;
                break;
            case MIN_ADJ: 
                time += 60;
                break;
            case SEC_ADJ: 
                time++;
                break;
            case NORMAL:
                break;
        }
        time %= 86400;
    }
    else if ( (key2 & 0xff) == 0xfc ) {
        switch( g_status ) {
            case HR_ADJ: 
                time += (86400-3600);
                break;
            case MIN_ADJ: 
                time += (86400-60);
                break;
            case SEC_ADJ: 
                time += (86400-1);
                break;
            case NORMAL:
                break;
        }
        time %= 86400;
    }
}

void port_init(void)
{
    PORTB = 0x00;
    DDRB = 0xff;
    PORTA = 0xff;
    PORTA &= ~_BV(3);
    DDRA = 0xff;
    DDRA &= (~_BV(6) & ~_BV(4) );
}

void timer0_init(void)
{
    TCCR0A = 0x83;              //stop
    TCCR0B = 0x01;
    OCR0A = 0x80;
}

void timer1_init(void)
{
    TCCR1B = 0x00;              //stop
    TCCR1A = 0x00;
    TCCR1B = 0x03;              // 64x prescaler
    TIMSK1 |= _BV(TOIE1);
}

void init_devices(void)
{
    cli();
    port_init();
    timer0_init();
    timer1_init();
    lcd_init();
    set_sleep_mode(SLEEP_MODE_IDLE);
    sleep_enable();
    sei();
    lcd_puts("Loading");
}

int main()
{
    init_devices();
    while (1) {
        sleep_cpu();
    }
    return 0;
}

ISR(TIM1_OVF_vect)
{
    static u8 k = 0;

    TCNT1 += 64911;             // interrupts every 125 counts
    k++;
    read_key();
    if( k >= 25 ) {
        k -= 25;
        update_disp();
    }
}
